# ECHOES: The Realm of Synergy — Android wrapper project

This Android Studio project packages the existing 3D prototype in a fullscreen Android WebView.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`ECHOES_Android_Project`) as a project.
3. Allow Android Studio to sync Gradle and install any requested Android SDK components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the output APK location. Transfer the APK to your Android phone and install it.

## Notes
- This is a starter Android project, not a precompiled APK.
- The 3D renderer (Three.js) is loaded from a CDN, so the first launch needs internet access.
- This wrapper provides an app icon/launcher entry, fullscreen landscape presentation, and Android touch input.
- For a production release, add a designed app icon, test on target devices, and consider bundling the 3D engine locally.

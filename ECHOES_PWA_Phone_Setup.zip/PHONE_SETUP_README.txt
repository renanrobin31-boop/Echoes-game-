# ECHOES — phone-only Android home-screen app setup

This package turns the ECHOES prototype into an installable Progressive Web App (PWA).
It is **not an APK**. It installs from a secure website and opens in an app-like window.

## Easiest phone-only setup (GitHub Pages)

1. Download and extract `ECHOES_PWA_Phone_Setup.zip` on your phone. If your phone's file manager cannot extract ZIPs, use its built-in Extract option or a trusted archive app.
2. In your phone browser, open https://github.com and sign in or create an account.
3. Create a **new public repository** named `echoes-game` (a public repo is the simplest option for free GitHub Pages).
4. Open the repository, choose **Add file → Upload files**, and upload the contents of this folder: `index.html`, `manifest.webmanifest`, `service-worker.js`, and the `icons` folder. Upload the files themselves, not the ZIP.
5. Commit the upload.
6. In the repository, open **Settings → Pages**. Under Build and deployment, select **Deploy from a branch**, choose branch `main` and folder `/ (root)`, then save.
7. Wait a minute or two. The Pages address will look like `https://YOUR-USERNAME.github.io/echoes-game/`. Open that address in Chrome on Android.
8. In Chrome, tap **⋮ → Add to Home screen** or **Install app** (the wording varies), then confirm.
9. Open ECHOES from the new home-screen icon. Landscape mode is recommended.

## Important notes

- GitHub Pages must serve the files over HTTPS for installation to work.
- The game uses Three.js from a CDN, so the first load needs internet. Basic app files are cached, but the game may not work fully offline until its 3D library has also been cached.
- If you see no Install app option, first open the published `https://...github.io/.../` address in Chrome (not the GitHub repository page), wait for it to finish loading, then check the ⋮ menu again.
- Do not share your GitHub password with anyone.
